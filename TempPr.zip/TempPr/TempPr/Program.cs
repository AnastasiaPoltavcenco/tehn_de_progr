﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace TempPr
{
    internal class Program
    {
        static Random Random = new Random();

        static void Main(string[] args)
        {
            var t = new OptionA();
            t.Run();
            Console.ReadKey();
        }

        class OptionA
        {
            class NumarRational
            {
                public double Result { get { return (double)Numerator / (double)Denominator; } }

                public long Numerator { get; }
                public long Denominator { get; }

                public NumarRational(long numerator)
                    : this(numerator, 1)
                {
                }

                public NumarRational(long numerator, long denominator)
                {
                    Numerator = numerator;

                    if (denominator == 0)
                    {
                        throw new DivideByZeroException("В знаменателе не может быть нуля");
                    }

                    Denominator = denominator;
                }

                // Операторный метод, который перегружает бинарный оператор '+',
                public static NumarRational operator +(NumarRational obj1, NumarRational obj2)
                {
                    if (obj1.Denominator == obj2.Denominator)
                    {
                        return new NumarRational(obj1.Numerator + obj2.Numerator, obj1.Denominator);
                    }

                    if (obj1.Denominator == 1)
                    {
                        return new NumarRational((obj1.Numerator * obj2.Denominator) + obj2.Numerator, obj2.Denominator);
                    }

                    if (obj2.Denominator == 1)
                    {
                        return new NumarRational(obj1.Numerator + (obj2.Numerator * obj1.Denominator), obj1.Denominator);
                    }

                    return new NumarRational((obj1.Numerator * obj2.Denominator) + (obj2.Numerator * obj1.Denominator), obj1.Denominator * obj2.Denominator);
                }

                // Операторный метод, перегружающий бинарный оператор '-',
                public static NumarRational operator -(NumarRational obj1, NumarRational obj2)
                {
                    if (obj1.Denominator == obj2.Denominator)
                    {
                        return new NumarRational(obj1.Numerator - obj2.Numerator, obj1.Denominator);
                    }

                    if (obj1.Denominator == 1)
                    {
                        return new NumarRational((obj1.Numerator * obj2.Denominator) - obj2.Numerator, obj2.Denominator);
                    }

                    if (obj2.Denominator == 1)
                    {
                        return new NumarRational(obj1.Numerator - (obj2.Numerator * obj1.Denominator), obj1.Denominator);
                    }

                    return new NumarRational((obj1.Numerator * obj2.Denominator) - (obj2.Numerator * obj1.Denominator), obj1.Denominator * obj2.Denominator);
                }

                // Метод, перегружающий оператор '*'
                public static NumarRational operator *(NumarRational obj1, NumarRational obj2)
                {
                    return new NumarRational(obj1.Numerator * obj2.Numerator, obj1.Denominator * obj2.Denominator);
                }

                // Перегрузка оператора '/' - деление комплексных чисел
                public static NumarRational operator /(NumarRational obj1, NumarRational obj2)
                {
                    return new NumarRational(obj1.Numerator * obj2.Denominator, obj1.Denominator * obj2.Numerator);
                }

                public override string ToString()
                {
                    if (Denominator == 1)
                    {
                        return Numerator.ToString();
                    }

                    return string.Format("{0}/{1}", Numerator, Denominator);
                }
            }

            private uint N;

            public void Run()
            {
                N = GetUIntFromReadConsole(Console.Write, "Please enter N : ");

                Console.WriteLine("Select input type : " + Environment.NewLine
                    + "1. Keyboard input" + Environment.NewLine
                    + "2. Random" + Environment.NewLine
                    + "3. Exit");
                var inputType = int.Parse(Console.ReadLine());

                var matrix = new NumarRational[N, N + 1];

                switch (inputType)
                {
                    case 1:

                        for (int i = 0; i < matrix.GetLength(0); i++)
                        {
                            for (int j = 0; j < matrix.GetLength(1); j++)
                            {
                                string s;
                                if (j == matrix.GetLength(1) - 1)
                                {
                                    s = "R = ";
                                }
                                else
                                {
                                    s = string.Format("X{0} = ", j);
                                }

                                matrix[i, j] = GetNumarRationalFromReadConsole(Console.Write, s);
                            }

                            Console.WriteLine("----------");
                        }

                        break;
                    case 2:

                        for (int i = 0; i < matrix.GetLength(0); i++)
                        {
                            for (int j = 0; j < matrix.GetLength(1); j++)
                            {
                                matrix[i, j] = new NumarRational(NextNumerator(), NextDenominator(Random.Next(0, 2)));
                            }
                        }

                        break;
                    default:
                        return;
                }

                CramersRule(matrix);
            }

            private void CramersRule(NumarRational[,] matrix)
            {
                Console.WriteLine("----------" + Environment.NewLine);

                var s = new StringBuilder();
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    s.Append("|");
                    for (int j = 0; j < matrix.GetLength(1); j++)
                    {
                        if (j == matrix.GetLength(1) - 1)
                        {
                            s.Append(string.Format(" = {0}", matrix[i, j]));
                        }
                        else
                        {
                            if (j != 0)
                            {
                                s.Append(string.Format(" + "));
                            }

                            s.Append(string.Format("{0}X{1}", matrix[i, j], j + 1));
                        }
                    }

                    s.Append(Environment.NewLine);
                }

                Console.WriteLine(s.ToString());
                Console.WriteLine("----------");


                var resultsLength = N + 1;
                NumarRational[] results = new NumarRational[resultsLength];

                for (int z = 0; z < resultsLength; z++)
                {
                    NumarRational[,] A = new NumarRational[N, N];

                    for (int i = 0; i < matrix.GetLength(0); i++)
                    {
                        for (int j = 0; j < matrix.GetLength(0); j++)
                        {
                            if (z == 0)
                            {
                                A[i, j] = matrix[i, j];
                                continue;
                            }

                            if ((z - 1) == j)
                            {
                                // Set Result
                                A[i, j] = matrix[i, matrix.GetLength(1) - 1];
                                continue;
                            }

                            A[i, j] = matrix[i, j];
                        }
                    }

                    var Dx = BareissAlgDeterminant(A);
                    results[z] = Dx;
                    Console.WriteLine("D{0} = {1}", z, Dx);
                }

                for (int i = 1; i < resultsLength; i++)
                {
                    NumarRational X = results[i] / results[0];
                    Console.WriteLine(string.Format("X{0} = D{0}/D = ({1})/({2}) = {3}/{4} (abs) = {5}",
                        i, results[i], results[0], Math.Abs(X.Numerator), Math.Abs(X.Denominator), Math.Abs(X.Result)));
                }
            }

            private NumarRational GetNumarRationalFromReadConsole<T>(Action<T> actionToShowMessage, T message)
            {
                actionToShowMessage(message);

                var value = Console.ReadLine();

                try
                {
                    return new NumarRational(int.Parse(value));
                }
                catch
                {
                    // ignore
                }

                var ds = value.Split(new string[] { CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator }, StringSplitOptions.RemoveEmptyEntries);
                if (ds.Length == 2)
                {
                    try
                    {
                        var dn = int.Parse(ds[1]);
                        var denumerator = NextDenominator((int)Math.Log10(dn) + 1);
                        return new NumarRational((int.Parse(ds[0]) * denumerator) + dn, denumerator);
                    }
                    catch
                    {
                        // ignore
                    }
                }

                var l = value.Split('/');
                if (l.Length == 2)
                {
                    try
                    {
                        return new NumarRational(int.Parse(l[0]), int.Parse(l[1]));
                    }
                    catch
                    {
                        // ignore
                    }
                }

                return GetNumarRationalFromReadConsole(actionToShowMessage, message);
            }

            public static uint GetUIntFromReadConsole<T>(Action<T> actionToShowMessage, T message)
            {
                actionToShowMessage(message);
                uint result = 0;
                try
                {
                    result = uint.Parse(Console.ReadLine());
                }
                catch
                {
                    return GetUIntFromReadConsole(actionToShowMessage, message);
                }

                if (result < 1)
                {
                    Console.WriteLine("Please enter N greater than 2");
                    return GetUIntFromReadConsole(actionToShowMessage, message);
                }

                return result;
            }

            private NumarRational BareissAlgDeterminant(NumarRational[,] mat)
            {
                int numberOfCols = mat.GetLength(1) - 1;
                for (int k = 0; k < numberOfCols; k++)
                {
                    for (int i = k + 1; i <= numberOfCols; i++)
                    {
                        for (int j = k + 1; j <= numberOfCols; j++)
                        {
                            NumarRational minEnd = mat[k, k] * mat[i, j];
                            NumarRational subtr = mat[i, k] * mat[k, j];
                            NumarRational result = (minEnd - subtr) / (k == 0 ? new NumarRational(1) : mat[k - 1, k - 1]);
                            mat[i, j] = result;
                        }
                    }
                }

                return mat[mat.GetLength(0) - 1, numberOfCols];
            }

            private int NextNumerator()
            {
                var res = Random.Next(-10, 10);

                if (res == 0)
                {
                    return NextNumerator();
                }

                return res;
            }

            private int NextDenominator(int range)
            {
                var denominator = 1;
                if (range != 0)
                {
                    for (int i = 0; i < range; i++)
                    {
                        denominator *= 10;
                    }
                }

                return denominator;
            }
        }
    }
}